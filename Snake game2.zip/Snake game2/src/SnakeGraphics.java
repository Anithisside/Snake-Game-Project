import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.Timer;

public class SnakeGraphics {
    private Image youWonImage;

    protected SnakeGraphics() {
        // Constructor
        try {
            // Load the "You Won" image
            youWonImage = ImageIO.read(new File("youwon.png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void paint(Graphics g, int[] snakexlength, int[] snakeylength, boolean right, boolean left, boolean up,
            boolean down, ImageIcon rightmouth, ImageIcon leftmouth, ImageIcon upmouth, ImageIcon downmouth,
            ImageIcon snakeimage, int[] applexpos, int[] appleypos, ImageIcon appleimage, Random random,
            int xpos, int ypos, int lengthofsnake, int moves, int scores, Level levelManager,
            SpeedManager speedManager, Timer timer) {

        int speedMultiplier = (int) speedManager.getSpeedMultiplier();

        if (moves == 0) {
            snakexlength[0] = 100;
            snakexlength[1] = 75;
            snakexlength[2] = 50;

            snakeylength[0] = 100;
            snakeylength[1] = 100;
            snakeylength[2] = 100;
        }

        // Draw the game elements
        // Draw the border for the title image
        g.setColor(Color.white);
        g.drawRect(24, 10, 851, 55);

        ImageIcon titleImage = new ImageIcon("snaketitle.png");
        titleImage.paintIcon(null, g, 25, 11);

        // Draw the border for the gameplay area
        g.setColor(Color.white);
        g.drawRect(24, 74, 851, 577);
        g.setColor(Color.BLACK);
        g.fillRect(25, 75, 850, 575);

        // Draw the scores, length, and level
        g.setColor(Color.black);
        g.setFont(new Font("arial", Font.BOLD, 24));
        g.drawString("Scores : " + scores, 750, 35);
        g.drawString("Level : " + levelManager.getCurrentLevel(), 750, 60);

        // Draw the snake and apple
        rightmouth = new ImageIcon("rightmouth.png");
        rightmouth.paintIcon(null, g, snakexlength[0], snakeylength[0]);

        for (int a = 0; a < lengthofsnake; a++) {
            if (a == 0 && right) {
                rightmouth = new ImageIcon("rightmouth.png");
                rightmouth.paintIcon(null, g, snakexlength[a], snakeylength[a]);
            }
            if (a == 0 && left) {
                leftmouth = new ImageIcon("leftmouth.png");
                leftmouth.paintIcon(null, g, snakexlength[a], snakeylength[a]);
            }
            if (a == 0 && up) {
                upmouth = new ImageIcon("upmouth.png");
                upmouth.paintIcon(null, g, snakexlength[a], snakeylength[a]);
            }
            if (a == 0 && down) {
                downmouth = new ImageIcon("downmouth.png");
                downmouth.paintIcon(null, g, snakexlength[a], snakeylength[a]);
            }

            if (a != 0) {
                snakeimage = new ImageIcon("snakeimage.png");
                snakeimage.paintIcon(null, g, snakexlength[a], snakeylength[a]);
            }
        }

        appleimage = new ImageIcon("apple.png");
        appleimage.paintIcon(null, g, applexpos[xpos], appleypos[ypos]);

        // Draw the "You Won" image if the player won the game
        if (levelManager.getCurrentLevel() == 5) {
            g.drawImage(youWonImage, 0, 0, null);
        }

        // Check if the game is over
        if (isGameOver(snakexlength, snakeylength, lengthofsnake)) {
            right = false;
            left = false;
            up = false;
            down = false;

            g.setColor(Color.WHITE);
            g.setFont(new Font("arial", Font.BOLD, 50));
            g.drawString("Game Over!", 300, 300);

            g.setFont(new Font("arial", Font.BOLD, 20));
            g.drawString("Space to RESTART", 350, 340);
            g.drawString("Enter to Exit", 350, 360);
        }

        // Calculate delay based on speed multiplier and level
        int levelDelay = speedManager.getDelayForLevel(levelManager.getCurrentLevel());
        int adjustedDelay = levelDelay / speedMultiplier;

        // Set the timer delay
        timer.setDelay(adjustedDelay);
        timer.start(); // Restart the timer with the new delay
    }

    // Method to check if the game is over
    private boolean isGameOver(int[] snakexlength, int[] snakeylength, int lengthofsnake) {
        // Check if the snake collides with itself
        for (int b = 1; b < lengthofsnake; b++) {
            if (snakexlength[b] == snakexlength[0] && snakeylength[b] == snakeylength[0]) {
                return true;
            }
        }

        // Check if the snake collides with the wall
        if (snakexlength[0] >= 850 || snakexlength[0] < 25 || snakeylength[0] >= 625 || snakeylength[0] < 75) {
            return false;
        }

        return false;
    }
}
