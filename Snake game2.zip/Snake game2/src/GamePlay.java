import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class GamePlay extends JPanel implements KeyListener, ActionListener {

    private int[] snakexlength = new int[750];
    private int[] snakeylength = new int[750];

    private boolean right = false;
    private boolean left = false;
    private boolean up = false;
    private boolean down = false;

    private ImageIcon rightmouth;
    private ImageIcon leftmouth;
    private ImageIcon upmouth;
    private ImageIcon downmouth;
    private ImageIcon snakeimage;

    private int[] applexpos = { 25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 325, 350, 375, 400, 425, 450,
            475, 500, 525, 550, 575, 600, 625, 650, 675, 700, 725, 750, 775, 800, 825, 850 };

    private int[] appleypos = {75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 325, 350, 375, 400, 425, 450, 475,
            500, 525, 550, 575, 600 };

    private ImageIcon appleimage;

    private Random random = new Random();

    private int xpos = random.nextInt(34);
    private int ypos = random.nextInt(23);

    private Timer timer;
    private int delay = 100;

    private int lengthofsnake = 3;
    private int moves = 0;
    private int scores = 0;

    private Level levelManager; // Level class instance
    private SpeedManager speedManager; // SpeedManager class instance

    public GamePlay(SpeedManager speedManager) {
        setLayout(null); // Set layout manager to null
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(true);
        timer = new Timer(delay, this);
        timer.start();

        this.levelManager = new Level(); // Initialize Level instance
        this.speedManager = speedManager; // Initialize SpeedManager instance
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(900, 600); // Set preferred size of the gameplay area
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        SnakeGraphics snakeGraphics = new SnakeGraphics();
        snakeGraphics.paint(g, snakexlength, snakeylength, right, left, up, down, rightmouth, leftmouth, upmouth, downmouth,
                snakeimage, applexpos, appleypos, appleimage, random, xpos, ypos, lengthofsnake, moves, scores,
                levelManager, speedManager, timer);
    }

    @Override
    public void actionPerformed(ActionEvent arg0) {
        if (applexpos[xpos] == snakexlength[0] && appleypos[ypos] == snakeylength[0]) {
            // Snake eats the food
            lengthofsnake++;
            scores++;
            if (scores % 5 == 0) {
                levelManager.incrementLevel();
            }
            // Generate new position for the food
            xpos = random.nextInt(34);
            ypos = random.nextInt(23);
        }

        if (isGameOver()) {
            gameOver(); // Call gameOver method if the game is over
            return; // Exit actionPerformed to prevent further execution
        }

        if (right) {
            for (int i = lengthofsnake - 1; i >= 0; i--) {
                snakeylength[i + 1] = snakeylength[i];
            }
            for (int i = lengthofsnake; i >= 0; i--) {
                if (i == 0) {
                    snakexlength[i] = snakexlength[i] + 25;
                } else {
                    snakexlength[i] = snakexlength[i - 1];
                }
                if (snakexlength[i] > 850) {
                    snakexlength[i] = 25;
                }
            }

            repaint();
        }

        if (left) {
            for (int i = lengthofsnake - 1; i >= 0; i--) {
                snakeylength[i + 1] = snakeylength[i];
            }
            for (int i = lengthofsnake; i >= 0; i--) {
                if (i == 0) {
                    snakexlength[i] = snakexlength[i] - 25;
                } else {
                    snakexlength[i] = snakexlength[i - 1];
                }
                if (snakexlength[i] < 25) {
                    snakexlength[i] = 850;
                }
            }

            repaint();
        }

        if (up) {
            for (int i = lengthofsnake - 1; i >= 0; i--) {
                snakexlength[i + 1] = snakexlength[i];
            }
            for (int i = lengthofsnake; i >= 0; i--) {
                if (i == 0) {
                    snakeylength[i] = snakeylength[i] - 25;
                } else {
                    snakeylength[i] = snakeylength[i - 1];
                }
                if (snakeylength[i] < 75) {
                    snakeylength[i] = 625;
                }
            }

            repaint();
        }
        if (down) {
            for (int i = lengthofsnake - 1; i >= 0; i--) {
                snakexlength[i + 1] = snakexlength[i];
            }
            for (int i = lengthofsnake; i >= 0; i--) {
                if (i == 0) {
                    snakeylength[i] = snakeylength[i] + 25;
                } else {
                    snakeylength[i] = snakeylength[i - 1];
                }
                if (snakeylength[i] > 625) {
                    snakeylength[i] = 75;
                }
            }

            repaint();
        }
    }

    // Method to check if the game is over
    private boolean isGameOver() {
        // Check if the snake collides with itself
        for (int b = 1; b < lengthofsnake; b++) {
            if (snakexlength[b] == snakexlength[0] && snakeylength[b] == snakeylength[0]) {
                return true;
            }
        }

        // Check if the snake collides with the wall
        if (snakexlength[0] >= 850 || snakexlength[0] < 25 || snakeylength[0] >= 625 || snakeylength[0] < 75) {
            return false;
        }

        // If the current level is greater than 5, consider the game over
        if (levelManager.getCurrentLevel() > 5) {
            return true;
        }

        return false;
    }

    // Method to handle game over
    private void gameOver() {
        GameOver.displayGameOver(); // Call the static method from GameOver class
        timer.stop(); // Stop the timer to prevent further movement
    }

    @Override
    public void keyPressed(KeyEvent e) {

        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

            moves++;
            if (!left) {
                right = true;
            } else {
                right = false;
                left = true;
            }
            up = false;
            down = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            moves++;
            if (!right) {
                left = true;
            } else {
                left = false;
                right = true;
            }
            up = false;
            down = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP) {
            moves++;
            if (!down) {
                up = true;
            } else {
                up = false;
                down = true;
            }
            left = false;
            right = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            moves++;
            if (!up) {
                down = true;
            } else {
                down = false;
                up = true;
            }
            left = false;
            right = false;
        }

        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            scores = 0;
            moves = 0;
            lengthofsnake = 3;
            levelManager.resetLevel(); // Reset level using Level class method
            repaint();
        }

        // Handle Enter key for exiting the game
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            // Exit the game
            System.exit(0);
        }
    }

    @Override
    public void keyReleased(KeyEvent arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    public void keyTyped(KeyEvent arg0) {
        // TODO Auto-generated method stub
    }
}

